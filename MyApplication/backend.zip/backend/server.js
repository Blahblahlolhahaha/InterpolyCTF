const app = require("./controller/app");



app.listen(3000,()=>[
    console.log("yes")
]);